This project is a First and Second Grade math game called Space Math. This game is built using Actionscript and the Starling
framework as well as PHP, HTML, CSS, and Flox. 

This repository contains all of the files and assets that we have written/created but this project requires having the Starling
framework included in the class path to fully function.

**Shia.mp3 was found at https://www.myinstants.com/instant/shia-labeouf-just-do-it/
**All other mp3 files came from either https://www.youtube.com/ or http://soundbible.com/
